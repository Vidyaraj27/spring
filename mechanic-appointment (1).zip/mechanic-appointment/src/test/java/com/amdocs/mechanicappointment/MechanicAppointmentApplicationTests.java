package com.amdocs.mechanicappointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MechanicAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
